# server
import sqlite3 as lite
import sys 
import hashlib
import socket
import threading
import thread
import datetime
import json
import os
import re
import shutil
import base64
import traceback

# server will reject files larger than this size
MAXDOWNLOADSIZE=1000000

# path where user files are stored 
directory = "users_files"
parent_dir="."
path = os.path.join(parent_dir, directory)

try:
    os.makedirs(path)
except :
    # directory already exists
    pass

''' COMMUNICATION SHOULD BE THROUGH HTTPS 
WE ASSUME IT HERE BUT FOR SIMPLICITY DO NOT IMPLEMENT
SECURE ENCRYPTED COMMUNICATION-- PASSWORDS ARE SENT OVER 
INTERNET NOT ENCRYPTED '''

def DropboxToSystemPath(path):
    ''' converting intenet path to local directories
    directories are seperated by vertical sign-"|", therefor
    we convert it to windows path'''
    return os.path.join(parent_dir,"users_files", path.replace("|","\\"))


class Database:
    ''' since sqlite is not thread safe, we create connections, we create 
    seperate connections to db in every thread. Established connections
    are stored in dictionary _threads'''
    _db = None
    _threads={} 
    _threadsCounts={}
    _file_name= "dropbox.db"
    def __init__(self, file_name="dropbox.db", *args, **kwargs):
        """ creating object Database """
        self.file_name= file_name
        thId= thread.get_ident()
        if thId in Database._threads:
            _threadsCounts[thId] += 1
            return
        _threadsCounts[thId]= 1    

    def close(self):
        ''' close thread connection '''
        thId= thread.get_ident()
        if thId in Database._threads:
            Database._threadsCounts[thId] -= 1
            if Database._threadsCounts[thId] ==0:
                Database._threads[thId].close()        
    def run(self):
        ''' unknown traces from previous version: works, dont touch '''
        if Database._thread:
            return
        Database._thread=threading.current_thread()
        self.db=lite.connect(self.file_name)
        while True:
            self.sqlEvent.wait()
            if "commit" in self.msg:
                self.db.commit()
            elif "sql" in self.msg:               
                cursor = self.db.cursor()
                cursor.execute(self.msg['sql'])
                self.msg= cursor
            self.sqlResponseEvent.set()
            self.sqlEvent.clear()
       
    @staticmethod
    def commit():
        ''' execute sqlite commit method for current thread '''
        thId= thread.get_ident()
        Database._threads[thId].commit()

    @staticmethod
    def connect( file_name="dropbox.db" ):
        ''' connect current thread to database '''
        thId= thread.get_ident()
        if not thId in Database._threads:
            try:
                Database._threads[thId]= lite.connect(Database._file_name)
            except lite.Error, e:
                print "Error %s:" % file_name
                sys.exit(1)
    
    @staticmethod
    def execute( sql ):
        ''' execute sql statement and return results '''
        thId= thread.get_ident()
        if not thId in Database._threads:
            Database.connect()
        cursor = Database._threads[thId].cursor()
        cursor.execute( sql )
        return cursor

class Model(object):
    ''' Partly reflects functionality of sql statement into python objects
    for simplified communication with database.
    In every derived class _field and _fieldOrder expected, they are used for
    reflection. They are used in createTable and select method to reflect the
    class attributes to database fields.'''
    def dropTable( self ):
        return Database.execute("DROP TABLE "+ self._table)
    def createTable( self ):
        sql="CREATE TABLE IF NOT EXISTS "+self._table+" "         
        sql+= '('+','.join([fld+' '+self._fields[fld][0]+' '+self._fields[fld][1] for fld in self._fieldOrder])+')'
        print sql
        Database.execute(sql)
    def delete(self, **kwargs):
        ''' cnd is a string that is added to the end of the sql statement that is sent
        to the database as is in order to control which records are delteted from
        the database'''
        if "cnd" in kwargs:
            cnd = kwargs["cnd"]    
        else:
            cnd= ""
        sql="DELETE FROM "+self._table+ " "+cnd
        print sql
        curr = Database.execute(sql)
        return curr
    def select( self, **kwargs ):
        ''' creates an object for every fetched record and signs the attributes
        with the names of the database fields with fetched values.
        for example- in UserModel, UserModel reflects users table which is 
        written in the field _table. This table has "userId","username","password" fields 
        which are described in the class variable _fields. _fieldOrder defines the 
        order in which the fields apear in the database.
        In select statement with cnd keyword, all records from the users table will
        be fetched and for each record a seperate object will be created.
        In each object 3 attributes "userId","username","password" will be created
        and a field with corresponding values from the record.'''
        fields =""
        if "fields" in kwargs:
            #TODO 
            ''' based on kwargs it was intended to create sql statement which
            will select only the fields specified in kwargs for efficiency.
            for simplicity wasnt implemented.'''
            pass
        else:
            fields="*"
        cnd =""
        if "cnd" in kwargs:
            cnd = kwargs["cnd"]        
        sql="SELECT "+fields+" FROM "+self._table+ " "+cnd
        print sql
        curr = Database.execute(sql)
        res =[]
        for row in curr:
            print row
            u = self.__class__()
            if fields == "*":
                for k,fld in enumerate(self._fieldOrder):
                    u.__setattr__(fld,row[k]) 
                res.append(u)
        return res
    def insert( self ):
        ''' inserts record with corresponding values to the attributes of
        class instance'''
        flds= [f for f in self._data if self._data[f]!= None ]
        vals= []
        for f in flds:
            if self._fields[f][0] == 'text':
                vals.append('"'+self._data[f]+'"')
            elif self._fields[f][0] == 'integer':
                vals.append(str(self._data[f]))
        sql = "INSERT INTO "+ self._table+" ("+','.join(flds)+\
        ') VALUES ('+ ','.join( vals ) +')'
        print sql
        curr= Database.execute(sql)
        Database.commit()
        return curr
    def numRecords(self):
        curr =  Database.execute("SELECT COUNT(*) FROM "+self._table)
        return [rec for rec in curr][0][0]
    def __init__ (self):
        ''' fills placeholders for attributes corresponding to fields in the 
        table'''
        self.__dict__['_data']={ k: None for k in self._fields}
    def __getattr__(self, name ):
        ''' returns the attribute corresponding to field '''
        if name in self._data:            
            return self._data[name]
        return self.__getattribute__( name )
        
    def __setattr__(self, name, val):
        ''' sets the value of attribute which represents the field of the table '''
        if name not in self._data:
            raise NameError
        # TODO check if type is correct
        ''' in large scale project should be implemented '''
        if self._fields[name][0]=='text':
            self._data[name]= str(val)
        elif self._fields[name][0]=='integer':
            self._data[name]= int(val)
    def __str__(self):
        return "%s - (%s)"%(self._table, ','.join( "%s:%s"%(k,self._data[k]) for k in self._data))
class UserModel(Model): 
    ''' class representing users table '''
    _table = 'users' # database table name
    # fields of the table and their sql properties (fieldName,(type,additional info))
    _fields={"username":("text","NOT NULL UNIQUE"),
            "password":("text","NOT NULL"),
            "userId":("integer","PRIMARY KEY")}
    _fieldOrder=["userId","username","password"]
    def __init__( self ):
        """Long expalnation in Model pays off by a single line of the 
        code in implementation"""
        super(UserModel,self).__init__()
class GroupModel(Model):  
    ''' class representing groups table '''
    _table = 'groups'
    _fields={"name":("text","NOT NULL UNIQUE"),
            "notes":("text",""),
            "groupId":("integer","PRIMARY KEY"),
            "ownerId":("integer","KEY")}
    _fieldOrder=["groupId","name","notes","ownerId"]
    def __init__( self ):
        super(GroupModel,self).__init__()
class UserGroupModel(Model):  
    ''' class representing usergroup table '''
    _table = 'usergroup'
    _fields={"userId":("integer","KEY"),
            "groupId":("integer","KEY")}
    _fieldOrder=["groupId","userId"]
    def __init__( self ):
        super(UserGroupModel,self).__init__()
class PermissionModel(Model):
    ''' class representing permissions table '''
    _table = 'permissions'
    _fields={"permissionId":("integer","KEY"),
            "userId":("integer","KEY"),
            "value":("text","")}
    _fieldOrder=["userId","permissionId","value"]
    def __init__( self ):
        super(PermissionModel,self).__init__()
class PermissionPathModel(Model):
    ''' class representing permissionsPath table '''
    _table = 'permissionsPath'
    _fields={"permissionId":("integer","KEY"),
            "userId":("integer","KEY"),
            "value":("text",""),
            "path":("text","KEY")}
    _fieldOrder=["userId","permissionId","path","value"]
    def __init__( self ):
        super(PermissionPathModel,self).__init__()    
class PermissionGroupPathModel(Model):
    ''' class representing permissionsGroupPath table '''
    _table = 'permissionsGroupPath'
    _fields={"permissionId":("integer","KEY"),
            "groupId":("integer","KEY"),
            "value":("text",""),
            "path":("text","KEY")}
    _fieldOrder=["groupId","permissionId","path","value"]
    def __init__( self ):
        super(PermissionGroupPathModel,self).__init__()    
class PermissionTypeModel(Model):
    ''' class representing permissionType table '''
    _table = 'permissionType'
    _fields={"permissionName":("text","UNIQUE"),
            "permissionId":("integer","PRIMARY KEY")}
    _fieldOrder=["permissionId","permissionName"]
    def __init__( self ):
        super(PermissionTypeModel,self).__init__()
class NoteModel(Model):
    ''' class representing notes table '''
    _table = 'notes'
    _fields={"noteClass":("text","KEY"),
            "name":("text","KEY"),
            "value":("text","NOT NULL")}
    _fieldOrder=["noteClass","name","value"]
    def __init__( self ):
        super(NoteModel,self).__init__()
class ServerThread(threading.Thread):
    ''' thread processing network communication '''
    def __init__(self,  *args, **kwargs):
        """Thread class with a stop() method. The thread itself has to check    
        regularly for the stopped() condition."""

        super(ServerThread, self).__init__(*args, **kwargs)
        self._stop_event = threading.Event()

    def stop(self):
        self._stop_event.set()

    def stopped(self):
        return self._stop_event.is_set()
    def run(self):
        print "starting server"
        HOST = '0.0.0.0' # any host 
        PORT = 50002
        BUFSIZ = 1024
        ADDR = (HOST,PORT)
        # creating TCP socket
        serversocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        serversocket.bind(ADDR)
        serversocket.listen(5)
        try:
            while not self.stopped():
                print "waiting for connection..."
                clientsock, addr = serversocket.accept()
                print "connected from: ",addr
                # handler has a blocking operation therefor
                # we start it as a new thread to allow other
                # clients to connect
                sh=ServerHandler(clientsock,addr)                
                sh.start()
                
        except KeyboardInterrupt:
            serversocket.close()   

def get_permissionId(permissionName):
    ''' returns permissionId by permissionName '''
    pt=PermissionTypeModel()
    print "obtaining permissionId for "+ permissionName
    rec=pt.select(cnd='WHERE permissionName="%s"'%permissionName)
    if len(rec)>0:
        return rec[0].permissionId
    return None
    
class ServerHandler(threading.Thread):
    ''' instance of this class is created for every connection. '''    
    def __init__(self, clientsock,addr,  *args, **kwargs):
        """Thread class . Since we start new thread for each connection,
        the client requests should also be treated seperatly. """

        super(ServerHandler, self).__init__(*args, **kwargs)
        self.clientsock=clientsock
        self.addr=addr
        self.downloadFiles={}
        # dictionary for methods processing specific client requests
        self.cmd={"login":self.login,
            "register":self.register,"listdir":self.listdir,
            "upload":self.upload,"delete":self.delete,
            "copy":self.copy,"move":self.move,
            "download":self.download, 'rename':self.rename,
            "getGroups":self.getGroups,"addGroup":self.addGroup,
            "deleteGroups":self.deleteGroups, 
            "getGroupDetails":self.getGroupDetails, 
            "addUserToGroup":self.addUserToGroup, 
            "deleteUsersFromGroup":self.deleteUsersFromGroup,
            "getPathUserPermissions":self.getPathUserPermissions,
            "getPathGroupPermissions": self.getPathGroupPermissions,
            "getPermissionList":self.getPermissionList,
            "addPathUserPermissions":self.addPathUserPermissions,
            "addPathGroupPermissions":self.addPathGroupPermissions,
            "delPathUserPermissions":self.delPathUserPermissions,
            "delPathGroupPermissions":self.delPathGroupPermissions }
    def register(self, msg):
        ''' processing request for register user '''
        u=UserModel()
        print "register cmd: ",msg
        
        if "username" in msg and "password" in msg:            
            username= msg["username"]
            password = msg["password"]
        else:
            self.running=False
            return  
        usrRec = u.select(cnd='WHERE username="%s"'%(username))
        if usrRec:
            self.clientsock.send("error: username exists")
            return
        u.username=username   
        u.password= hashlib.sha256(username+password).hexdigest()
        cur=u.insert()        
        path = os.path.join(parent_dir, directory,username)
        try:
            os.mkdir(path)
          
        except Exception as err:
            print err
            self.clientsock.send("error: internal server error")
            return
        
        userId=cur.lastrowid
        print userId
        self.login(msg)
        try:
            for permName in ["DOWNLOADFOLDER","RENAMEFILE",
        "UPLOADFILE", "UPLOADFOLDER","READFILE","WRITEFILE",
        "DOWNLOADFILE","DELETEFILE","CHANGEFILENAME",
        "CHANGEFOLDERNAME","DELETEFOLDER","VIEWFOLDER", "SET_PERMISSION"]:
                ptId=get_permissionId(permName)
                print permName , ptId
                give_permission_byID(username,self.user,ptId)
            Database.commit()
        except Exception as err:
            print "error",err
            self.clientsock.send("error: internal server error")
            return
    def login(self,msg):
        """ processing request for login user. 
        
        if no username or password in msg ignore msg
        and close connection - this is not our program"""
        print "login cmd: ",msg #log
        if "username" in msg and "password" in msg:            
            username= msg["username"]
            password = msg["password"]
        else:
            self.running=False
            return  
        if not re.search('^[A-Za-z][A-Za-z0-9_]*$', username):
            # username should start with a letter and
            # include only digits, letters and underscores
            self.clientsock.send("error: not allowed user name")
            return
        u = UserModel()
        usrRec = u.select(cnd='WHERE username="%s"'%(username))
        if not usrRec:           
            self.clientsock.send("error: invalid user or password")
            return
        if usrRec[0].password!=hashlib.sha256(username+password).hexdigest():
            self.clientsock.send("error: invalid user or password")
            return
            
        self.user=usrRec[0]
        self.clientsock.send("ok")
    def run(self):
    
        ''' dispatcher - distributes processing of client requests
        to request specific methods'''
        self.user=None # no user is associated with the thread yet
        self.running = True
        self.clientsock.send("+") # handshake
        while self.running:
            # loop breaks down in 2 conditions
            # if client requests to disconnect
            # or communication with the client is lost
            data = self.clientsock.recv(1024)
            try:
                msg =json.loads(data)
                print msg,msg["cmd"]
                
                if "cmd" in msg:
                    print "got cmd ", msg["cmd"] 
                    if msg["cmd"] in self.cmd:
                        try:
                            # call request-specific processing method
                            self.cmd[msg["cmd"]](msg)
                        except Exception as err:
                            # printing debugging information 
                            # and informing client about the error
                            ex_type, ex_value, ex_traceback = sys.exc_info()
                            self.clientsock.send("error:"+str(err) )
                            print err
                            for ln in traceback.extract_tb(ex_traceback):
                                print ln

                    continue
            except ValueError as err:
                print data
                print(err)
               
            # conditions to exit
            if data == "Q" or data=="q":
                break             
            if not data:
                break
            self.clientsock.send(data)
        self.clientsock.send("server: quit")
        self.clientsock.close()
    def getPermissionList(self,msg):
        ''' returns list of permissions which can be set by user '''
        pt= PermissionTypeModel()
        pTypesRec= pt.select()   
        print pTypesRec
        pTypes= [p.permissionName for p in pTypesRec if p.permissionName not in ["SUPERUSER", "SET_PERMISSION"]]
        print pTypes
        self.clientsock.send( json.dumps( pTypes) )
    def checkPathPermission(self,msg,permType):
        ''' check if logged in user has permission of permType for the 
        path specified in msg['path']'''
        if not "path" in msg: # wrong message
            self.clientsock.send("error: no path in request")
            return False
        permissionType=get_permissionId(permType)
        permission=has_permission(msg["path"], self.user, permissionType)
        if not permission:
            self.clientsock.send("error: you don't have permission")
            return False
        return True
    def delPathUserPermissions(self, msg):
        ''' delete permissions specified in msg['permissions'] for the user 
        specified in msg['user'] and for path specified in msg['path']'''
        print msg
        if not all( k in msg for k in ['path', 'user', 'permissions'] ):
            self.clientsock.send("error: not enough arguments")
        u= UserModel()
        uId= u.select( cnd=' WHERE username="%s"'%msg['user'] )
        if not uId:
            self.clientsock.send("error: no such user")        
        pp= PermissionPathModel()
        if msg['permissions']=='*':
            # remove all permissions
            pp.delete( cnd = ' WHERE path="%s" AND userId="%d"'%( msg['path'], uId[0].userId) )
        else:
            # remove individual permissions
            for p in msg["permissions"]:
                pId= get_permissionId(p)
                pp.delete( cnd = ' WHERE path="%s" AND userId="%d" AND permissionId=%d'%( msg['path'], uId[0].userId, pId ) )
        Database.commit()
        self.clientsock.send("ok")
    def delPathGroupPermissions(self, msg):
        '''delete permissions specified in msg['permissions'] for the group 
        created by the logged in user specified in msg['group'] and for path
        specified in msg['path']'''
        print msg
        if not all( k in msg for k in ['path', 'user', 'permissions'] ):
            self.clientsock.send("error: not enough arguments")
        g= GroupModel()
        gId= g.select( cnd=' WHERE name="%s"'%msg['user'] )
        if not gId:
            self.clientsock.send("error: no such group")  
        pp= PermissionGroupPathModel()
        if msg['permissions']=='*':
            # remove all permissions
            pp.delete( cnd = ' WHERE path="%s" AND groupId=%d'%( msg['path'], gId[0].groupId) )
        else:
            # remove individual permissions
            for p in msg["permissions"]:
                pId= get_permissionId(p)
                pp.delete( cnd = ' WHERE path="%s" AND groupId=%d AND permissionId=%d'%( msg['path'], gId[0].groupId, pId ) )
        Database.commit()
        self.clientsock.send("ok")
    def addPathUserPermissions(self, msg):
        ''' add permissions specified in msg['permissions'] for the user 
        specified in msg['user'] and for path specified in msg['path'] '''
        print msg
        if not all( k in msg for k in ['path', 'user', 'permissions'] ):
            self.clientsock.send("error: not enough arguments")
        if not self.checkPathPermission( msg, "SET_PERMISSION" ):
            self.clientsock.send("error: not enough permissions")
        pp= PermissionPathModel()
        u= UserModel()
        uId= u.select( cnd=' WHERE username="%s"'%msg['user'] )
        if not uId:
            self.clientsock.send("error: no such user")
            return
        pp.userId= uId[0]. userId
        pp.path=msg['path']
        for p in msg["permissions"]:
            pp.permissionId= get_permissionId(p)
            pp.insert()
        Database.commit()
        self.clientsock.send("ok")
    def addPathGroupPermissions(self, msg):
        ''' add permissions specified in msg['permissions'] for the group
        created by loged in user specified in msg['group'] and for path 
        specified in msg['path'] '''
        print msg
        if not all( k in msg for k in ['path', 'user', 'permissions'] ):
            self.clientsock.send("error: not enough arguments")
            return
        if not self.checkPathPermission( msg, "SET_PERMISSION" ):
            self.clientsock.send("error: not enough permissions")
            return
        pp= PermissionGroupPathModel()
        g= GroupModel()
        uId= g.select( cnd=' WHERE name="%s" and ownerId=%d'%(msg['user'], self.user.userId))
        if not uId:
            self.clientsock.send("error: no such group you've created")
            return
        pp.groupId= uId[0]. groupId
        pp.path=msg['path']
        for p in msg["permissions"]:
            pp.permissionId= get_permissionId(p)
            pp.insert()
        Database.commit()
        self.clientsock.send("ok")
    def getPathUserPermissions(self, msg):
        ''' returns all users that have any/some permissions 
        to specified path in msg['path']'''
        print msg
        if not "path" in msg:
            self.clientsock.send("error: path should be in message")
            return
        path= msg["path"]
        pp=PermissionPathModel()
        pt=PermissionTypeModel()
        u=UserModel()
        recs=pp.select(cnd='WHERE path="%s"'%path) 
        if not recs:
            self.clientsock.send(json.dumps([]))
            return
        pTypesRec=pt.select(cnd='WHERE permissionId IN (%s)'%",".join(set(["%d"%uu.permissionId for uu in set(recs)])) )
        pType={p.permissionId:p.permissionName for p in pTypesRec}
        users=set([ uu.userId for uu in recs])
        cnd= 'WHERE userId IN (%s)'%",".join(["%d"%uu for uu in users])
        #print cnd
        perminfo= []
        userRecs=u.select(cnd=cnd) 
        #print 'userRecs, ',userRecs, 
        if userRecs:
            usernames={uu.userId:uu.username for uu in userRecs}
            perminfo=[(usernames[r.userId],pType[r.permissionId]) for r in recs]
        self.clientsock.send(json.dumps(perminfo))
    def getPathGroupPermissions(self, msg):
        ''' returns all groups created by logged in user that have 
        any/some permissions to specified path in msg['path']'''
        print msg
        if not "path" in msg:
            self.clientsock.send("error: path should be in message")
            return
        path= msg["path"]
        pgp=PermissionGroupPathModel()
        pt=PermissionTypeModel()
        g=GroupModel()
        recs=pgp.select(cnd=',groups WHERE path="%s" AND  permissionsGroupPath.groupId=groups.groupId AND groups.ownerId=%d'%(path,self.user.userId))
        print "got recs", recs
        if not recs:
            self.clientsock.send(json.dumps([]))
            return
        pTypesRec=pt.select(cnd='WHERE permissionId IN (%s)'%",".join( set(["%d"%uu.permissionId for uu in recs]))) 
        pType={p.permissionId:p.permissionName for p in pTypesRec}
        groups=set([ uu.groupId for uu in recs])
        print groups
        groupRecs=g.select(cnd='WHERE groupId IN (%s)'%",".join(["%d"%uu for uu in groups])) 
        perminfo=[]
        if groupRecs:
            groupnames={uu.groupId:uu.name for uu in groupRecs}
            perminfo=[(groupnames[r.groupId],pType[r.permissionId]) for r in recs]
        self.clientsock.send(json.dumps(perminfo))
            
    def listdir(self,msg):
        ''' sends client list of files and dirs in directory specified
        by msg['path'] according to logged in user permissions to view
        this folder'''
        if not "path" in msg:
            self.clientsock.send("error: path should be in message")
            return
        path= msg["path"]
        permissionType=get_permissionId("VIEWFOLDER")
        permission=has_permission(path, self.user, permissionType)
        print "listdir, permission: ",permission
        if not permission:
            self.clientsock.send("error: you don't have permission")
            return
        ospath = DropboxToSystemPath(path)
        listAll={}
        print ospath
        if os.path.isfile(ospath):
            listAll[os.path.basename(path)]={"type":"file"}        
        elif os.path.isdir(ospath):
            ls=os.listdir(ospath)
            for file in ls:
                if os.path.isfile(os.path.join(ospath, file)):
                    listAll[file]={"type":"file"}
                elif os.path.isdir(os.path.join(ospath, file)):
                    listAll[file]={"type":"dir"}
            print ls, listAll
        self.clientsock.send(json.dumps(listAll))
    def upload(self,msg):
        ''' uploads file specified in path msg['path'] if file
        size is less than MAXDOWNLOADSIZE and user has permission
        to upload this file'''
        if not "path" in msg: # wrong message
            self.clientsock.send("error: no path in request")
            return
        if msg["type"]=="file":
            if "size" in msg:
                # check size
                if msg["size"]>MAXDOWNLOADSIZE:
                    self.clientsock.send("error: max upload size "+str(MAXDOWNLOADSIZE))
                    return
                
                # check permission
                permissionType=get_permissionId("UPLOADFILE")
                permission=has_permission(msg["path"], self.user, permissionType)
                if not permission:
                    self.clientsock.send("error: you don't have permission")
                    return               
                self.clientsock.send("ok, send content")
                size= msg["size"]
                try:
                        # recieving content of the file in chunks of 1 kb
                        sysPath=DropboxToSystemPath(msg["path"])          
                        with open(sysPath,"wb") as fd:
                            s= 0
                            #file opened
                            while s < size:
                                e= min(s+1024, size)
                                chSize= e-s
                                chunk= self.clientsock.recv(chSize)  
                                fd.write(chunk)
                                s= e
                        self.clientsock.send("ok, saved")
                except Exception as err:
                        self.clientsock.send("error: ",err)
                        return
            else:
                self.clientsock.send("error: size or content should be in the message")
                return
        elif msg["type"]=="dir":
            permissionType=get_permissionId("UPLOADFOLDER")
            permission=has_permission( msg["path"], self.user, permissionType )
            if not permission:
                self.clientsock.send("error: you don't have permission")
                return
            sysPath=DropboxToSystemPath(msg["path"])
            print "creating directory ", msg["path"], sysPath
            os.mkdir( sysPath )
            self.clientsock.send("ok, send files")
    def move(self, msg):
        ''' moves files from one directory to another '''
        if not all( [k in msg for k in ["from", "to"]] ):
            self.clientsock.send("error: not enough arguments")
            return
        if len(msg['from']) == len(msg['to']):
            # one to one move
            for f,t in zip( msg['from'], msg['to'] ):
                fp= DropboxToSystemPath( f )
                tp= DropboxToSystemPath( t )
                shutil.move(fp, tp)
                sql= 'UPDATE permissionsGroupPath SET path="%s" WHERE path="%s"'%(tp,fp)
                print sql
                Database.execute( sql )
                sql= 'UPDATE permissionsPath SET path="%s" WHERE path="%s"'%(tp,fp)
                print sql
                Database.execute( sql )
                Database.commit()
        elif len(msg['to'])==1:
            # seen to be copy files to directory
            tp= DropboxToSystemPath( msg['to'][0] )
            for f in msg['from']:
                fp= DropboxToSystemPath( f )
                shutil.move( fp,tp )
                sql= "UPDATE permissionsGroupPath SET path=%s WHERE path=%s"%(tp,fp)
                print sql
                Database.execute( sql )
                sql= "UPDATE permissionsPath SET path=%s WHERE path=%s"%(tp,fp)
                print sql
                Database.execute( sql )
                Database.commit()
        else:
           self.clientsock.send("error: could not understand arguments")
           return
        self.clientsock.send("ok") 
    def copy(self, msg):
        ''' copy files from msg['from'] to mag['to'] '''
        if not all( [k in msg for k in ["from", "to"]] ):
            self.clientsock.send("error: not enough arguments")
            return
        if len(msg['from']) == len(msg['to']):
            # one to one move
            for f,t in zip( msg['from'], msg['to'] ):
                fp= DropboxToSystemPath( f )
                tp= DropboxToSystemPath( t )
                shutil.copy(fp, tp)
                sql= 'INSERT INTO permissionsGroupPath (groupId, permissionId, path) SELECT groupId, permissionId, "%s" FROM permissionsGroupPath WHERE path="%s"'%(t, f)
                print sql
                Database.execute( sql )
                sql= 'INSERT INTO permissionsPath (userId, permissionId, path) SELECT userId, permissionId, "%s" FROM permissionsPath WHERE path="%s"'%(t, f)
                print sql
                Database.execute( sql )
                Database.commit()
        elif len(msg['to'])==1:
            # seen to be copy files to directory
            tp= DropboxToSystemPath( msg['to'][0] )
            for f in msg['from']:
                fp= DropboxToSystemPath( f )
                shutil.copy( fp,tp )
                sql= 'INSERT INTO permissionsGroupPath (groupId, permissionId, path) SELECT groupId, permissionId, "%s" FROM permissionsGroupPath WHERE path="%s"'%(t, f)
                print sql
                Database.execute( sql )
                sql= 'INSERT INTO permissionsPath (userId, permissionId, path) SELECT userId, permissionId, "%s" FROM permissionsPath WHERE path="%s"'%(t, f)
                print sql
                Database.execute( sql )
                Database.commit()
        else:
           self.clientsock.send("error: could not understand arguments")
           return
        self.clientsock.send("ok") 
    def rename( self, msg ):
        ''' rename file specified in msg[' path'] to msg['newPath'] according
        to permissions '''
        if not self.checkPathPermission( msg, "RENAMEFILE"): return
        oldPath= DropboxToSystemPath(msg["path"])
        newPath= DropboxToSystemPath(msg["newPath"])
        try:
            os.rename( oldPath, newPath )
            self.clientsock.send("ok, renamed")
        except Exception as err:
            self.clientsock.send("error: ",err)
    
    def delete(self,msg):
        ''' delete file or dir specified in msg['path'] according to 
        permissions '''
        if not "path" in msg: # wrong message
            self.clientsock.send("error: no path in request")
            return
        if msg["type"]=="file":
            permissionType=get_permissionId("DELETEFILE")
            print "permission for file:", permissionType
            permission=has_permission(msg["path"], self.user, permissionType)
            if not permission:
                self.clientsock.send("error: you don't have permission")
                return
            try:
                sysPath=DropboxToSystemPath(msg["path"]) 
                os.remove(sysPath)
                self.clientsock.send("ok, removed")
                print "file deleted"
            except Exception as err:
                self.clientsock.send("error: ",err)
                return
        elif msg["type"]=="dir":
            permissionType=get_permissionId("DELETEFOLDER")
            permission=has_permission( msg["path"], self.user, permissionType )
            if not permission:
                self.clientsock.send("error: you don't have permission")
                return
            try:
                sysPath=DropboxToSystemPath(msg["path"]) 
                shutil.rmtree(sysPath)
                self.clientsock.send("ok, removed")
            except Exception as err:
                self.clientsock.send("error: ",err)
    def download(self,msg, lastFile= True):
        ''' send file specified in msg['path']to client according to permissions '''
        if not "path" in msg: # wrong message
            self.clientsock.send("error: no path in request")
            return
        sysPath=DropboxToSystemPath(msg["path"]) 
        print 'downloading ', sysPath, msg
        try:
            if os.path.isfile(sysPath):                                  
                if not self.checkPathPermission(msg,"DOWNLOADFILE"):
                    return
                print "got permission"
                with open(sysPath,"rb") as fd:
                    content=fd.read()
                print "sending result"
                self.clientsock.send(json.dumps({"path":msg["path"],"type":"file",
                "size":len(content)}))
                msg= self.clientsock.recv(1024)
                print "got ", msg
                if 'ok' in msg:
                    size= len(content)
                    s= 0
                    while s< size:
                        e= min(s+1024, size)
                        self.clientsock.send(content[s:e])
                        s= e
                print "sent"
                msg= self.clientsock.recv(1024)
                print msg
            elif os.path.isdir(sysPath):
                print "downloading dir"
                if not self.checkPathPermission(msg,"DOWNLOADFOLDER"): return
                reply= json.dumps({"path":msg["path"],"type":"dir"})
                print "sending: ", reply
                self.clientsock.send( reply)                
                reply=self.clientsock.recv(1024)
                print reply
                if reply=="ready":
                    ls=os.listdir(sysPath)
                    for file in ls:                       
                        oldPath=msg["path"]
                        msg["path"]+="|"+file
                        self.download(msg, False)
                        msg["path"]=oldPath
            if lastFile:
                self.clientsock.send('""')
        except Exception as err:
            print "got exception"
            self.clientsock.send("error: ",err)
    def deleteUsersFromGroup(self, msg):
        ''' delete users specified in msg['usernames'] from  group 
        specified in msg['grName'] according to permissions'''
        if not "grName" in msg:
            self.clientsock.send("error: groupname should be in message")
            return
        if not "usernames" in msg:
            self.clientsock.send("error: username should be in message")
            return
        u = UserModel()
        user= u.select( cnd= ' WHERE username in ("%s")'%'","'.join( msg["usernames"] ) )
        if not user:
            self.clientsock.send("error: usernames do not exists")
            return
        g=GroupModel()
        group= g.select( cnd= ' WHERE name="%s"'%( msg["grName"] ) )
        if not group:
            self.clientsock.send("error: group does not exists")
            return
        ug=UserGroupModel()
        ug.delete( cnd = " WHERE groupId=%d and userId in (%s)"%( group[0].groupId ,
            ','.join( ["%d"%uu.userId for uu in user]) ) )
        self.clientsock.send("ok ")
    def addUserToGroup(self, msg ):
        ''' add users specified in msg['usernames'] from  group 
        specified in msg['grName'] according to permissions'''
        if not "grName" in msg:
            self.clientsock.send("error: groupname should be in message")
            return
        if not "user" in msg:
            self.clientsock.send("error: username should be in message")
            return
        g=GroupModel()
        u = UserModel()
        ug=UserGroupModel()
        user= u.select( cnd= ' WHERE username="%s"'%( msg["user"] ) )
        if not user:
            self.clientsock.send("error: username does not exists")
            return
        ug.userId= user[0].userId
        group= g.select( cnd= ' WHERE name="%s"'%( msg["grName"] ) )
        if not group:
            self.clientsock.send("error: group does not exists")
            return
        ug.groupId= group[0].groupId
        ug.insert()
        self.clientsock.send("ok ")
    def getGroups(self,msg):
        ''' send client list of created groups by him '''
        g=GroupModel()
        groupNames=g.select(cnd= 'WHERE ownerId=%d'%self.user.userId)
        print groupNames
        self.clientsock.send(json.dumps({"groupNames":[gr.name for gr in groupNames]}))

    def addGroup(self,msg):
        ''' associate group specified in msg['grName'] in database'''
        if not "grName" in msg:
            self.clientsock.send("error: groupname should be in message")
            return
        g=GroupModel()
        ug=UserGroupModel()
        g.name=msg["grName"]
        g.ownerId=self.user.userId
        curr=g.insert()
        ug.groupId=curr.lastrowid
        ug.userId=self.user.userId
        ug.insert()
        self.clientsock.send("ok") 
    def deleteGroups(self,msg):
        ''' remove groups specified in msg['groupNames'] according to 
        logged in user permissions - only groups created by user'''
        print "deteling Groups ", msg
        if not "groupNames" in msg:
            self.clientsock.send("error: groupnames should be in message")
            return
        g=GroupModel()
        ownerId=self.user.userId
        cnd= 'WHERE name in ("%s")'%'","'.join( msg["groupNames"] )
        print 'cnd=', cnd
        curr= g.select( cnd= cnd )
        grIds= ["%d"%c.groupId for c in curr]
        g.delete( cnd= cnd )
        cnd2= "WHERE groupId in (%s)"%','.join( grIds )
        print 'cnd2 = ', cnd2
        UserGroupModel().delete( cnd= cnd2 )
        Database.commit()
        self.clientsock.send( 'ok ')
    def getGroupDetails(self,msg):
        ''' sends cilent usernames that are signed to group specified
        in msg['grName'] according to permission'''
        if not "grName" in msg:
            self.clientsock.send("error: groupname should be in message")
            return
        u = UserModel()
        ug=UserGroupModel()
        g=GroupModel()
        data= g.select( cnd= ' WHERE name="%s" and ownerId=%d'%(msg['grName'], 
            self.user.userId ) )
        print "getGroupDetails", data
        if not data:
            self.clientsock.send("error: no such group")
            return
        resp= {}
        users= ug.select( cnd= " WHERE groupId=%d"%data[0].groupId )
        print "getGroupDetails users", bool(users), users
        if users:
            cnd= " WHERE userId in (%s)"%','.join( ['%d'%uu.userId for uu in users])
            print cnd
            usernames = u.select( cnd= cnd ) 
            print "getGroupDetails ", usernames
            resp['users']= [uu.username for uu in usernames]
        self.clientsock.send(json.dumps(resp))
def give_permission(path,userRec,permissionTypeRec):
    ''' sets permissions for user specified in userRec and permissionType
    specified in permissionTypeRec. helper function.'''
    give_permission_byID(path,userRec,permissionTypeRec.permissionId)
def give_permission_byID(path,userRec,permissionId):
    '''  sets permissions for user specified in userRec and permissionId
    specified in permissionId. helper function. '''
    pm=PermissionPathModel()
    pm.userId=userRec.userId
    pm.permissionId=permissionId
    pm.path=path
    print "trying to insert"
    pm.insert()
    
def has_group_permission( path, groupId, permissionType):
    ''' checks if group specified in groupId has permission specified
    in permissionType to path specified in path. helper function'''
    pm=PermissionGroupPathModel()
    typeRec=pm.select(cnd='WHERE groupId=%d AND path="%s" AND permissionId=%d'%(groupId,path, permissionType))
    if len(typeRec)>0:
        return True
    # check if there is parent directory 
    re_result=re.match("^(.+)\|[A-Z.a-z][A-Za-z.0-9_]*$",path)
    print "group permissions", re_result
    if re_result:
        # check permission recursively in parent directory
        return has_group_permission( re_result.group(1),groupId,permissionType )

def has_permission( path, userRec, permissionType, origPath= None):
    ''' checks if user specified in userRec has permission specified
    in permissionType to path specified in path. helper function '''
    print "checking permissions for ", path, userRec, permissionType, origPath
    if path[-1] == '|':
        path= path[:-1]
    if origPath==None:
        pRec= PermissionModel().select( cnd=', permissionType WHERE userId=%d AND permissions.permissionId=permissionType.permissionId AND permissionName="SUPERUSER"'%userRec.userId )
        if pRec:
            print "we have superuser!! all on a knee!!"
            return True
        origPath= path
    pm=PermissionPathModel()
    user=userRec.userId
    typeRec=pm.select(cnd='WHERE userId=%d AND path="%s" AND permissionId=%s'%(user,path,permissionType))
    if len(typeRec)>0:
        return True
    re_result=re.match("^(.+)\|[A-Z.a-z][A-Za-z.0-9_]*$",path)
    if re_result:
        #found path, re_result.group(0),re_result.group(1)
        return has_permission( re_result.group(1),userRec,permissionType, origPath )
    # user has no permissions    
    # but he can have permissions as a group
    
    ug= UserGroupModel()
    grRec= ug.select( cnd='WHERE userId=="%s"'%userRec.userId )
    for gr in grRec:
        if has_group_permission( origPath, gr.groupId, permissionType ):
            return True
    
    return False 
      
    
    
try:
    Database.connect()
except lite.Error, e:
    print "Error %s:" % file_name
    sys.exit(1)
print "Opened database successfully";   

#############################################################
#                                                           #
#                   init database                           #
#                                                           #
#############################################################
pType=PermissionTypeModel()
pType.createTable()
p=PermissionModel()
p.createTable()
if pType.numRecords()==0:
    for t in ["SUPERUSER","DOWNLOADFOLDER","RENAMEFILE",
        "UPLOADFILE", "UPLOADFOLDER","READFILE","WRITEFILE",
        "DOWNLOADFILE","DELETEFILE","CHANGEFILENAME",
        "CHANGEFOLDERNAME","DELETEFOLDER","VIEWFOLDER", "SET_PERMISSION"]:
        pType.permissionName=t
        pType.insert()
u= UserModel()
u.createTable()
NoteModel().createTable()
PermissionGroupPathModel().createTable()
PermissionPathModel().createTable()
UserGroupModel().createTable()
GroupModel().createTable()

#############################################################
#                                                           #
#                 creating superuser                        #
#                                                           #
#############################################################
typeRec=pType.select(cnd='WHERE permissionName="SUPERUSER"')[0]
if len(u.select())==0:
    print "Congratulations! You are the SUPERUSER!"
    usr = raw_input("please enter your username: ")    
    while True:
        password1=raw_input("enter your password: ")
        password2=raw_input("retype your password: ")
        if password1==password2:
            break
    u.username=usr   
    u.password= hashlib.sha256(usr+password2).hexdigest()
    cur=u.insert()
    userId=cur.lastrowid
    print userId
    p.permissionId=typeRec.permissionId
    p.userId=userId
    p.insert()

superuser = p.select( cnd="WHERE permissionId= %d"%typeRec.permissionId )[0]
superuser = u.select( cnd="WHERE userId=%d"%superuser.userId)

server=ServerThread()
server.start()
usrRec=False

#############################################################
#                                                           #
#     CLI-command line interface                            #
#                                                           #
#############################################################

while not usrRec:
    usr=raw_input("please enter username: ")
    pwd=raw_input("password: ")
    usrRec = u.select(cnd='WHERE username="%s"'%(usr))
    if not usrRec:
        continue
    if usrRec[0].password!=hashlib.sha256(usr+pwd).hexdigest():
        continue
    typeRec=pType.select(cnd='WHERE permissionName="SUPERUSER"')[0]
    if not p.select(cnd="WHERE userId=%d AND permissionId=%d"%(usrRec[0].userId,typeRec.permissionId)):
        continue
    print "hello superuser"
    t0=datetime.datetime.now()   
    while True:
        cmd=raw_input("=>")
        if (datetime.datetime.now()-t0).seconds>300:
            usrRec=False
            break
        if cmd=="quit":
            thread.interrupt_main()
            server.stop()
            server.join()
            break
