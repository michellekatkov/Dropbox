from socket import *
from Tkinter import *
import tkFileDialog
import tkFont
import json
import os
import functools
import re
import base64

''' COMMUNICATION SHOULD BE THROUGH HTTPS 
WE ASSUME IT HERE BUT FOR SIMPLICITY DO NOT IMPLEMENT
SECURE ENCRYPTED COMMUNICATION-- PASSWORDS ARE SENT OVER 
INTERNET NOT ENCRYPTED '''

def read_free_port():
    ''' reads file saved by server to get an open port '''
    f = open("port.txt", "r")
    return int(f.read())

def send_rec(data):
    ''' sends and recieves data to/from server '''
    try:
        clientsocket.send(data)
        listbox.insert(END, data)
        data = clientsocket.recv(BUFSIZ)
        listbox.insert(END, data)
        if (not data) or data=="server: quit":
            root.quit()
        
    except IOError as e:
        # connection to server lost
        print "No connection to server"
        root.quit()

def handler(event):
    ''' sends current input to the server and
    displays the answer in the listbox '''
    data = cmd.get()
    cmd.set("") # clear input field
    send_rec(data)
        
def on_closing():
    ''' windows close button handler '''
    # sends goodbye to server and recieves answer
    clientsocket.send("q")
    data = clientsocket.recv(BUFSIZ)
    root.quit()
    
def listhandler(event):
     ''' sends first selected line in the listbox
     to server and appends the answer to the listbox'''
     sel = listbox.curselection()
     if len(sel)==0:
         return # nothing selected
     # get content of the first selected line
     data = listbox.get(sel[0])
     send_rec(data)
     
def errorDialog(data):
    ''' displayes error dialog '''
    dialog= Toplevel()
    Label( dialog, text= data ).pack()
    Button(dialog, text = "Got it",font=fnt,command= lambda: dialog.destroy() ).pack() 

def DropboxToSystemPath(path, parent_dir ):
    ''' converting intenet path to local directories
    directories are seperated by vertical sign-"|", therefor
    we convert it to windows path'''
    return os.path.join(parent_dir, path.replace("|","\\"))       
class Login:
    ''' defines GUI element and processes events for login activity '''
    def __init__(self,sock):
        ''' dont remember, works dont touch '''
        self.sock=sock 
    def login(self):
        ''' sends login request to server. according to reply 
        displays error dialog/main frame '''
        msg= json.dumps( {'cmd': 'login', 'password': password.get(), 'username': username.get()} )
        print msg
        self.sock.send(msg)
        data=self.sock.recv(1024)
        if data=="ok":
            print "logged in"
            loginFrame.pack_forget()
            mainFrame.pack(fill= BOTH)
            mf.initWindow()
        else:
            errorDialog(data)
    def register(self):
        ''' sends register request to server. according to reply 
        displays error dialog/main frame '''
        if password.get()==password2.get():
            self.sock.send( json.dumps( {'cmd': 'register', 'password': password.get(), 'username':username.get() } ))
            data=self.sock.recv(1024)
            if data=="ok":
             
                print "registered"
                registerFrame.pack_forget()
                mainFrame.pack( fill=BOTH )
                mf.initWindow()
            else:
                errorDialog(data)                       
        else:
            errorDialog(data)

class UsersInGroupFrame:
    ''' defines GUI element and processes events for UsersInGroupFrame
    activity (related to activity of managing users in group)'''
    def __init__( self, gf ):
        ''' defining GUI elements '''
        self.gf= gf
        self.mf= gf.mf
        self.usersFrame= Frame( self.mf.mainFrame )
        self.groupCheckbtns=[]
        self.selectAllVar=IntVar()
        self.groupNameLabels= []
        self.addGroupDialogStarted= False
        
        
        if True: # for identation
          self.titleLabel= Label(self.usersFrame, font= fnt, fg="#000040")
          self.toolbar= Frame( self.usersFrame )
          self.bottombar= Frame( self.usersFrame )
        
          self.titleLabel.pack()
          self.toolbar.pack()
          self.bottombar.pack()

          self.listfileFrameTop=Frame(self.usersFrame, background= "#F8F8F8")
          self.canvas=Canvas(self.listfileFrameTop)
          self.listUsers=Frame(self.canvas, background= "#F8F8F8")
          scrollbar=Scrollbar(self.listfileFrameTop,orient="vertical",command=self.canvas.yview)
          self.canvas.config( yscrollcommand=scrollbar.set)
          scrollbar.pack(side="right",fill="y")
          self.canvas.pack(side="left", fill=BOTH, expand=1)
          self.canvas.create_window((0,0),window=self.listUsers,anchor='nw')
          self.listUsers.bind("<Configure>",lambda _: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

          self.listfileFrameTop.pack(fill=BOTH)
          
          backImg=PhotoImage(file="icons8-back-50.gif")  
          self.backBt=Button( self.toolbar, image=backImg, command=self.hide )
          self.backBt.image=backImg
          self.backBt.pack(side="left")
          ttp_backBt=CreateToolTip(self.backBt,"Back")
          
          addImg=PhotoImage(file="icons8-add-user-50.gif")  
          self.addBt=Button( self.toolbar, image=addImg,command=self.addUserDialog )
          self.addBt.image=addImg
          self.addBt.pack(side="left")
          ttp_addBt=CreateToolTip(self.addBt,"Add User")
          
          delImg=PhotoImage(file="icons8-empty-trash-50.gif")  
          self.delBt=Button( self.toolbar, image=delImg,command=self.deleteUsers )
          delImg.image=delImg
          self.delBt.pack(side="left")
          ttp_delBt=CreateToolTip(self.delBt,"Delete User")
    def addUserDialog(self):
        ''' displays dialog for adding user to group '''
        if self.addGroupDialogStarted:
            return
        self.addGroupDialogStarted= True
        self.grNameVar=StringVar()
        dialog= Toplevel()
        Label( dialog, text= "UserName: ",font=fnt ).pack(side='left')
        Entry(dialog,text = self.grNameVar, font=fnt ).pack(side="left")
        Button(dialog, text = "Submit",font=fnt,
           command= functools.partial( self.serverRequestAddUser, dialog )   ).pack()
        Button(dialog, text = "Cancel",font=fnt,
           command= functools.partial( self.serverRequestAddGroupCancel, dialog )   ).pack()
        dialog.protocol("WM_DELETE_WINDOW", functools.partial( self.serverRequestAddGroupCancel, dialog ) )
        
    def serverRequestAddGroupCancel(self, dialog):
        ''' updates status of addGroupDialogStarted and closes dialog '''
        self.addGroupDialogStarted= False       
        dialog.destroy()        
    def serverRequestAddUser(self,dialog):
        ''' sends request to server to add specified user (from dialog)
        to group '''
        dialog.destroy()
        clientsocket.send(json.dumps({"cmd":"addUserToGroup",
            "grName":self.titleLabel['text'],
            "user": self.grNameVar.get() }))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
        self.showGroup( self.titleLabel['text'] )
        self.addGroupDialogStarted= False        
    def _getMarked( self ):
        ''' returns all marked usernames '''
        return [lbl["text"] for btn, lbl in zip(self.groupCheckbtnsVar, self.groupNameLabels ) if btn.get()==1 ]    
    def deleteUsers(self):
        ''' sends request to server to remove marked users from group'''
        marked=self._getMarked()
        print "delete ", marked
        clientsocket.send(json.dumps({"cmd":"deleteUsersFromGroup",
           "usernames":marked,
           "grName": self.titleLabel['text'] }))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
        self.showGroup( self.titleLabel['text'] )
    def show(self):
        ''' displays userframe hides groupframe '''
        self.gf.groupFrame.pack_forget()
        self.usersFrame.pack(fill=BOTH)
    def hide(self):
        ''' displays groupframe hides userframe '''
        self.usersFrame.pack_forget()
        self.gf.groupFrame.pack(fill=BOTH)
    def showGroup( self, grName, ev=None ):
        ''' fills in information in GUI component
        about users in created group'''
        self.titleLabel['text']= grName
        clientsocket.send(json.dumps( {"cmd":"getGroupDetails", "grName":grName } ))
        msg= clientsocket.recv(1024)
        print "got ", msg
        data = json.loads(msg)
        print "got from server: ", data
        for bt in self.groupCheckbtns:
            bt.destroy()
        self.groupCheckbtns=[]
        self.groupCheckbtnsVar= []
        for l in self.groupNameLabels:
            l.destroy()
        self.groupNameLabels= []
        
        if 'users' in data:
            for gi, grName in enumerate(data['users']):
                var= IntVar()
                chBt=Checkbutton ( self.listUsers, variable=var )
                chBt.grid(column=0,row=gi)
                print 'creating label', grName
                l=Label( self.listUsers, text=grName, font=fnt)
                l.grid(column=1,row=gi)
                        
                self.groupNameLabels.append(l)
                self.groupCheckbtns.append(chBt)
                self.groupCheckbtnsVar.append(var)

        
        self.show()

        
class GroupFrame:
    ''' defines GUI element and processes events for GroupFrame
    activity (related to activity of managing groups)'''
    def __init__(self, mf ):
        ''' defining GUI elements. 
        stupidly implemented the same functionality like UsersInGroupFrame.'''
        self.mf= mf
        mf.setGroupFrame(self)
        self.userInGroupFrame= UsersInGroupFrame(self)
        self.groupFrame= Frame( mf.mainFrame )
        self.groups=[]
        self.groupCheckbtns=[]
        self.selectAllVar=IntVar()
        self.groupNameLabels= []
        self.addGroupDialogStarted= False
        
        if True: #for identation
          self.toolbar= Frame( self.groupFrame )
          self.bottombar= Frame( self.groupFrame )
          
          self.toolbar.pack(fill='y')
          selectButton = Checkbutton(self.toolbar, text="Select All", command=self.select_all, variable= self.selectAllVar)
          selectButton.pack(side="left")
          addGroupImg=PhotoImage(file="icons8-add-group-50.gif")  
          self.addBt=Button( self.toolbar, image=addGroupImg,command=self.addGroupDialog )
          self.addBt.image=addGroupImg
          self.addBt.pack(side="left")
          ttp_addBt=CreateToolTip(self.addBt,"Add Group")
          
          delGroupImg=PhotoImage(file="icons8-empty-trash-50.gif")  
          self.delBt=Button( self.toolbar, image=delGroupImg,command=self.deleteGroups )
          self.delBt.image=delGroupImg
          self.delBt.pack(side="left")
          ttp_deleteBt=CreateToolTip(self.delBt,"Delete Group")
          
          
          
          
        self.listgroupFrameTop=Frame(self.groupFrame, background= "#F8F8F8")
        self.canvas=Canvas(self.listgroupFrameTop)
        self.listGroups=Frame(self.canvas, background= "#F8F8F8")
        scrollbar=Scrollbar(self.listgroupFrameTop,orient="vertical",command=self.canvas.yview)
        self.canvas.config( yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right",fill="y")
        self.canvas.pack(side="left", fill=BOTH, expand=1)
        self.canvas.create_window((0,0),window=self.listGroups,anchor='nw')
        self.listGroups.bind("<Configure>",lambda _: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.listgroupFrameTop.pack(fill=BOTH, expand=1)
    def select_all(self): 
        ''' selects all groups '''
        if self.selectAllVar.get():
            for item in self.groupCheckbtns:            
                item.select()
        else:
            for item in self.groupCheckbtns:            
                item.deselect() 
    
    def deleteGroups(self):
        ''' send request to server to delete selected groups.'''
        marked=self._getMarked()
        print "delete ", marked
        clientsocket.send(json.dumps({"cmd":"deleteGroups","groupNames":marked}))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
        self.updateGroupList()
    def addGroupDialog(self):
        ''' displays new dialog which creates new group associated 
        with logged in user'''
        if self.addGroupDialogStarted:
            return
        self.addGroupDialogStarted= True
        self.grNameVar=StringVar()
        dialog= Toplevel()
        Label( dialog, text= "GroupName: ",font=fnt ).pack(side='left')
        Entry(dialog,text = self.grNameVar, font=fnt ).pack(side="left")
        Button(dialog, text = "Submit",font=fnt,
           command= functools.partial( self.serverRequestAddGroup, dialog )   ).pack()
        Button(dialog, text = "Cancel",font=fnt,
           command= functools.partial( self.serverRequestAddGroupCancel, dialog )   ).pack()
        dialog.protocol("WM_DELETE_WINDOW", functools.partial( self.serverRequestAddGroupCancel, dialog ) )
        
    def serverRequestAddGroupCancel(self, dialog):
        ''' updates status of addGroupDialogStarted and closes dialog '''
        self.addGroupDialogStarted= False        
        dialog.destroy()        
    def serverRequestAddGroup(self,dialog):
        ''' sends request to server to create group with specicfied name
        (from dialog) '''
        dialog.destroy()
        clientsocket.send(json.dumps({"cmd":"addGroup","grName":self.grNameVar.get()}))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
        self.updateGroupList()
        self.addGroupDialogStarted= False        
    def initGroupFrame(self):
        ''' hides main frime, displayes groupframe '''
        self.userInGroupFrame.hide()
        self.updateGroupList()
    def updateGroupList(self):
        ''' sends request to server to get list of groups
        created by logged in user'''
        clientsocket.send(json.dumps( {"cmd":"getGroups"} ))
        # server will return empty array if no groups
        # else, returns array with group names
        self.groups=json.loads(clientsocket.recv(1024))['groupNames']
        print "got groups: ", self.groups
        self.updateGroupGUI( )
    def hide(self):
        self.userInGroupFrame.hide()
    def updateGroupGUI(self):
        ''' requests groups from server and displays them '''
        for bt in self.groupCheckbtns:
            bt.destroy()
        self.groupCheckbtns=[]
        self.groupCheckbtnsVar= []
        for l in self.groupNameLabels:
            l.destroy()
        self.groupNameLabels= []
        
        for gi, grName in enumerate(self.groups):
            var= IntVar()
            chBt=Checkbutton ( self.listGroups, variable=var )
            chBt.grid(column=0,row=gi)
            # print 'creating label', grName
            l=Label( self.listGroups, text=grName, font=fnt)
            l.grid(column=1,row=gi)
            l.bind('<Button-1>', 
                      functools.partial( self.userInGroupFrame.showGroup, grName ))                    
            self.groupNameLabels.append(l)
            self.groupCheckbtns.append(chBt)
            self.groupCheckbtnsVar.append(var)
    def _getMarked( self ):
        ''' returns all marked groups '''
        return [lbl["text"] for btn, lbl in zip(self.groupCheckbtnsVar, self.groupNameLabels ) if btn.get()==1 ]    
class MainFrame:
    ''' defines GUI element and processes events for MainFrame
    activity (related to activity of managing files)'''
    def __init__ (self,mainFrame):
        ''' defining GUI elements.  '''
        self.mainFrame= mainFrame
        topFrame= Frame(mainFrame)
        
        self.toMove= []
        self.toCopy= []
        self.moveIt= None

        if True: # for identation
            imageGroups = PhotoImage(file="icons8-google-groups-70.gif")  
            self.GroupsBtn=Button( topFrame, image=imageGroups, command=self.showGroupsFrame)            
            self.GroupsBtn.image= imageGroups
            ttp_groupsBt=CreateToolTip(self.GroupsBtn,"GROUPS")
            self.GroupsBtn.pack(side="left")
            
            imageFiles = PhotoImage(file="icons8-document-70.gif")  
            self.FilesBtn=Button( topFrame, image=imageFiles, command=self.showFilesFrame)
            self.FilesBtn.image= imageFiles
            ttp_groupsBt=CreateToolTip(self.FilesBtn,"FILES")
            self.FilesBtn.pack(side="left")
            
            fill= Label(topFrame, text="")   
            fill.pack( side='left',fill='x', expand= 1 )
            self.helloLabel=Label(topFrame, text="Hello %s !"%username.get(), font=fnt)
            #self.helloLabel.grid(row=0,column=0,sticky= N+S+E+W,columnspan=3)
            self.helloLabel.pack(side= 'right' )
        topFrame.pack( fill= 'x')
            
        self.pathFrame=Frame(mainFrame)
        self.pathFrame.pack(fill='x')
        self.curDirVar= StringVar()
        
        Button(self.pathFrame, text="path:", command=self.setPathShow ).pack(side="left")
        self.pathLabel= Label( self.pathFrame, textvariable= self.curDirVar, font= fnt )
        self.pathLabel.pack( fill='x' )
        self.setPathEntry= Entry( self.pathFrame, textvariable= self.curDirVar, font= fnt )
        self.setPathEntry.bind( '<Return>', self.setPath )
        self.setPathEntry.bind( "<Escape>", self.setPathCancel )
        self.setPathset=Button(self.pathFrame, text="set", command=self.setPath )
        
        self.filesFrame= Frame( mainFrame )
        self.pf=PermissionFrame( self )        
        self.filesFrame.pack(fill=BOTH)

        
        self.toolbarFrame= Frame( self.filesFrame )
        self.selectAllVar= IntVar()
        if True:# for identation

            selectButton = Checkbutton(self.toolbarFrame, text="Select All", command=self.select_all, variable= self.selectAllVar)
            selectButton.pack(side="left")
           
            image1 = PhotoImage(file="icons8-cut-50.gif")      
            self.cutBt=Button(self.toolbarFrame, image=image1, command=self.cutFiles )
            self.cutBt.image= image1
            ttp_cutBt=CreateToolTip(self.cutBt,"CUT")
            self.cutBt.pack(side="left")

            image2 = PhotoImage(file="icons8-copy-50.gif")      
            self.copyBt=Button(self.toolbarFrame, image=image2, command=self.copyFiles)
            self.copyBt.image= image2
            ttp_copyBt=CreateToolTip(self.copyBt,"COPY")
            self.copyBt.pack(side="left")

            image3 = PhotoImage(file="icons8-paste-50.gif")      
            self.pasteBt=Button(self.toolbarFrame, image=image3, command=self.pasteFiles)
            self.pasteBt.image= image3
            ttp_pasteBt=CreateToolTip(self.pasteBt,"PASTE")
            self.pasteBt.pack(side="left")
            
            image4 = PhotoImage(file="icons8-empty-trash-50.gif")      
            self.delBt=Button(self.toolbarFrame, image=image4,command=self.delSelected)
            self.delBt.image= image4
            self.delBt.pack(side="left")
            ttp_delBt=CreateToolTip(self.delBt,"DELETE")
            
            image5=PhotoImage(file= "icons8-download-50.gif") 
            self.downloadBt=Button(self.toolbarFrame, image=image5,command=self.downloadSelected)
            self.downloadBt.image= image5
            self.downloadBt.pack(side="left")
            ttp_downloadBt=CreateToolTip(self.downloadBt,"DOWNLOAD")
            
            image6=PhotoImage(file= "icons8-back-50.gif")
            self.backBt=Button(self.toolbarFrame, image=image6,command=functools.partial( self.changeDir, ".." ))
            self.backBt.image= image6
            self.backBt.pack(side="left")
            ttp_backBt=CreateToolTip(self.backBt,"Back")

        else: # variation
            self.selectAllVar= IntVar()
            selectButton = Checkbutton(mainFrame, text="Select All", command=self.select_all, variable= self.selectAllVar)
            selectButton.grid(row=1,column=0)
            Button(mainFrame, image = "icons8-copy-100.png",font=fnt,command=self.delSelected).grid(row=2,column=1,sticky= N+S+E+W)
            self.delBt=Button(mainFrame, text = "DELETE",font=fnt,command=self.delSelected)
            self.delBt.grid(row=1,column=1,sticky= N+S+E+W)
            self.downloadBt=Button(mainFrame, text = "DOWNLOAD",font=fnt,command=self.downloadSelected)
            self.downloadBt.grid(row=1,column=2,sticky= N+S+E+W)
            self.backBt=Button(mainFrame, text = "Back",font=fnt,command=functools.partial( self.changeDir, ".." ))
            self.backBt.grid(row=1,column=3,sticky= N+S+E+W)
        
        
        self.listfileFrameTop=Frame(self.filesFrame, background= "#F8F8F8")
        self.canvas=Canvas(self.listfileFrameTop)
        self.listfileFrame=Frame(self.canvas, background= "#F8F8F8")
        scrollbar=Scrollbar(self.listfileFrameTop,orient="vertical",command=self.canvas.yview)
        self.canvas.config( yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right",fill="y")
        self.canvas.pack(side="left", fill=BOTH, expand=1)
        self.canvas.create_window((0,0),window=self.listfileFrame,anchor='nw')
        self.listfileFrame.bind("<Configure>",lambda _: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        
        
        self.curDir=""
        self.curDirVar.set('obana')
        self.files={}
        self.fileLabels=[]
        self.fileCheckbtns=[]
        self.fileCheckbtnsVar=[]
        self.fileOptionsPanel=[]
        self.lock=False
        
        # grid
        for k in range(10):
            l=Label(self.listfileFrame, text="", font=fnt)
            l.grid(row= k, column= 1 , sticky=N+S+E+W)
            self.fileLabels.append(l)

        self.optionsFrame=Frame(self.filesFrame)
        Label(self.optionsFrame, text="UPLOAD  ", font=fnt).pack(side= "left")
        
        upFileImg=PhotoImage(file= "icons8-add-file-70.gif")
        upFileBt=Button(self.optionsFrame, image=upFileImg,command=self.uploadFile)
        upFileBt.image= upFileImg
        upFileBt.pack(side="left")
        ttp_upFile=CreateToolTip(upFileBt,"File")
        
        upFolderImg=PhotoImage(file= "icons8-add-folder-70.gif")
        upFolderBt=Button(self.optionsFrame, image=upFolderImg,command=self.uploadDir)
        upFolderBt.image= upFolderImg
        upFolderBt.pack(side="left")
        ttp_upFolder=CreateToolTip(upFolderBt,"Folder")
        
        self.toolbarFrame.pack(fill=BOTH)
        self.listfileFrameTop.pack(fill=BOTH, expand=1)
        self.optionsFrame.pack(fill="y")

    def cutFiles(self):
        ''' save files toMove '''
        self.toMove= [self.curDir+f for f in self._getMarked()]
        self.moveIt= True
    def copyFiles(self):
        ''' save files to copy '''
        self.toCopy= [self.curDir+f for f in self._getMarked()]
        self.moveIt= False
    def pasteFiles(self):
        ''' send request to server to copy or move saved files. '''
        if self.moveIt == None:
            return
        if self.moveIt:
            clientsocket.send(json.dumps({"cmd":"move","from": self.toMove, "to" : [self.curDir]} ) )
        else:
            clientsocket.send(json.dumps({"cmd":"copy","from": self.toCopy, "to" : [self.curDir]} ) )
        resp= clientsocket.recv(1024)
        print resp
        if not "ok" in resp:
            errorDialog(resp)
        self.moveIt= None
        self.updateDirFiles()        
    def setGroupFrame(self, gf):
        self.gf=gf
    def showGroupsFrame(self):
        ''' displays group frame, hides all other frames '''
        self.filesFrame.pack_forget()
        self.pf.hide()
        self.gf.initGroupFrame()
        self.gf.groupFrame.pack(fill=BOTH)
    def showFilesFrame(self):
        ''' displays files frame, hides all other frames '''
        self.gf.hide()
        self.pf.hide()
        self.curDirVar.set(self.curDir)
        self.gf.groupFrame.pack_forget()
        self.filesFrame.pack(fill=BOTH)
    def showPermissionFrame(self):
        ''' displays permissions frame, hides all other frames '''
        self.filesFrame.pack_forget()        
        self.pf.show(  )
    def setPath(self, ev=None):
        ''' reads path label and changes current dir to entered path by user '''
        self.curDir= self.curDirVar.get()
        self.setPathCancel()
        self.updateDirFiles(  )
    def setPathCancel(self, ev=None ):
        ''' hides entry, displays file name again '''
        self.pathLabel.pack(side="right",fill='x', expand=1 ) 
        self.setPathEntry.pack_forget()
        self.setPathset.pack_forget()
    def setPathShow(self, ev=None):
        ''' hides file name, displays entry again '''
        self.pathLabel.pack_forget()
        self.setPathEntry.pack(side="left", fill='x', expand=1)
        self.setPathset.pack(side="right")
    def select_all(self): 
        ''' selects all files/dirs in current directory'''
        if self.selectAllVar.get():
            for item in self.fileCheckbtns:            
                item.select()
        else:
            for item in self.fileCheckbtns:            
                item.deselect()
    def canvas_configure():
        canvas.configure(scrollregion=canvas.bbox("all"))
    def initWindow(self):
        ''' fill initial information about just logged in user '''
        self.helloLabel['text']="Hello %s !"%username.get()
        self.curDir=username.get()+"|"
        self.curDirVar.set(self.curDir)
        # send server request for list of files in root directory
        clientsocket.send(json.dumps( {'cmd': 'listdir', 'path': username.get() } ))
        self.files= json.loads(clientsocket.recv(1024))
        print self.files
        if "error" in self.files:
            errorDialog(self.files)
            return        
        self.updateFileGUI()
    def updateDirFiles( self ):
        ''' request server to update content of the current directory  '''
        clientsocket.send(json.dumps( {'cmd': 'listdir', 'path': self.curDir } ))
        msg= clientsocket.recv(1024)
        try:
            self.files= json.loads( msg )
        except Exception as err:
            print msg
            print err
            self.files=[] 
        print self.files
        if "error" in self.files:
            errorDialog(self.files)
            #TODO
            return False
        self.updateFileGUI()
        return True
    def _uploadFile(self, filename ): 
        '''  request server to upload file specified in filename.  '''
        if self.lock:
            return
        file = os.path.basename(filename)
        size = os.stat(filename).st_size
        clientsocket.send(json.dumps({"cmd":"upload","type":"file","size":size
        ,"path":self.curDir+file}))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
            return
        with open( filename,"rb") as fd:
            content=fd.read()
        s= 0
        while s< size:
            e= min(s+1024, size)
            clientsocket.send(content[s:e])
            s= e;
        reply=clientsocket.recv(1024)
        print "_uploadFile server reply", reply
        if "error" in reply:
            errorDialog(reply)
            return
        self.files[file]={"type":"file"}
        self.updateFileGUI()        
    def uploadFile(self): 
        '''displays file dialog to select the file to upload to server.'''
        if self.lock:
            return
        print "upload request"
        filename=tkFileDialog.askopenfilename(initialdir = "/",title = "Select file")
        print filename
        if filename:
            self._uploadFile(filename)
    def _uploadDir(self, dirname):
        ''' request server to upload directory specified in dirname. '''
        if self.lock:
            return
        name = os.path.basename(dirname)
        clientsocket.send(json.dumps({"cmd":"upload","type":"dir","path":self.curDir+name}))
        reply=clientsocket.recv(1024)
        print "_uploadDir server reply", reply
        if "error" in reply:
            errorDialog(reply)
            return
        ls=os.listdir(dirname)
        curDir= self.curDir
        self.curDir +=  name+'|'
        for fname in ls:
            fullfile= os.path.join( dirname, fname )
            print fullfile
            if os.path.isfile(fullfile):
                self._uploadFile( fullfile )
            elif os.path.isdir(fullfile):
                self._uploadDir( fullfile )
        self.curDir= curDir        
    def uploadDir(self): 
        '''displays directory dialog to select the directory to upload to server.'''
        if self.lock:
            return
        print "upload request"
        dirname=tkFileDialog.askdirectory (initialdir = "/",title = "Select dir" )
        print dirname
        if dirname:
            self._uploadDir(dirname)
            print "done uploading dir"
            self.updateDirFiles()
    
    def changeDir(self, dir, a=None):
        ''' changes current directory '''
        if self.lock:
            return
        if dir =='..':
            re_result=re.match("^(.+\|)[A-Z.a-z][A-Za-z.0-9_]*\|?$",self.curDir)
            print "dir: ",re_result,self.curDir
            if re_result:
                self.curDir= re_result.group(1)
                self.curDirVar.set(self.curDir)
        else:
            # TODO: check correctness of dir name
            self.curDir+= dir+'|'
            self.curDirVar.set(self.curDir)
        print self, dir, a, self.curDir
        self.updateDirFiles()
    
    def updateFileGUI(self):
        ''' displays updated content of current path '''
        for bt in self.fileCheckbtns:
            bt.destroy()
        self.fileCheckbtns=[]
        
        self.fileCheckbtnsVar=[]
        
        for w in self.fileOptionsPanel:
            w.destroy()
        self.fileOptionsPanel=[]

        for li, f in enumerate(self.files): 
            if li<len(self.fileLabels):
                var= IntVar()  
                Grid.rowconfigure(self.listfileFrame, 0, weight=1)
                Grid.columnconfigure(self.listfileFrame, 0, weight=1)
                chBt=Checkbutton ( self.listfileFrame, variable=var )
                chBt.grid(column=0,row=li,sticky= N+S+E+W)
                self.fileCheckbtns.append(chBt)
                self.fileCheckbtnsVar.append(var)
                self.fileLabels[li]['text']=f
                if self.files[f]['type'] == 'dir':
                    self.fileLabels[li]['fg']='purple'
                    self.fileLabels[li].bind('<Button-1>', 
                      functools.partial( self.changeDir, f ))                      
                else:
                    self.fileLabels[li]['fg']='black'
                    self.fileLabels[li].bind('<Button-1>', lambda x: x )

            else:   
                if self.files[f]['type'] == 'dir':
                    l=Label(self.listfileFrame, text=f, font=fnt, fg= "purple" )
                    l.bind('<Button-1>', 
                      functools.partial( self.changeDir, f ))
                    
                else:
                    l=Label(self.listfileFrame, text=f, font=fnt )                
                l.grid(row= li, column=1,sticky= N+S+E+W )                
                self.fileLabels.append(l)
                var= IntVar()                
                chBt=Checkbutton ( self.listfileFrame, variable= var )
                chBt.grid(column=0,row=li,sticky= N+S+E+W)
                self.fileCheckbtns.append(chBt)
                self.fileCheckbtnsVar.append(var)
            Grid.rowconfigure(self.listfileFrame, li, weight=1)
            Grid.columnconfigure(self.listfileFrame, 3, weight=1)
            of= Frame( self.listfileFrame )
            l=Label(of, text='rename', font=fnt, fg= "gray" )
            l.bind('<Button-1>', 
              functools.partial( self.rename, li ))
            l.pack(side='left')
            l=Label(of, text='share', font=fnt, fg= "gray" )
            l.bind('<Button-1>', 
              functools.partial( self.share, f ))
            l.pack(side='left')
            of.grid( column=2, row=li, sticky=N+S+W+E )
            self.fileOptionsPanel.append(of)
        #print li, self.files
        #for li in range(li,10):
        #    #print li,len(self.fileLabels)
        #    self.fileLabels[li]["text"]= " "
        #    self.fileLabels[li]['fg']='black'
        #    self.fileLabels[li].bind()
        for li in range(len(self.files),len(self.fileLabels)):
            print "destroying ", self.fileLabels[li]
            self.fileLabels[li].destroy()            
         
        self.fileLabels=self.fileLabels[:len(self.files)]
        self.fileCheckbtns=self.fileCheckbtns[:len(self.files)]
    def share(self, fname, ev=None):
        ''' displays frame to manage permissions to other users '''
        print "share ", fname
        self.curDirVar.set(self.curDir+fname)
        self.pf.initPermissionFrame(self.curDir+fname)
        self.showPermissionFrame()
    
    def renameFinish( self, lab, e, newName, li, ev=None ):
        ''' hides rename entry, displays new name or old name on escape '''
        root.bind( '<Return>' )
        root.bind( '<Escape>' )
        e.destroy()
        lab.grid(row=li,column=1)
        clientsocket.send(json.dumps({"cmd":"rename","path":self.curDir+lab["text"], 
            'newPath':self.curDir+newName.get() }))
        resp= clientsocket.recv(1024)
        print resp
        if not "ok" in resp:
            errorDialog(resp)
        else:
            self.updateDirFiles()
        self.lock=False
    
    def renameCancel( self, lab, e, newName, li, ev=None ):
        ''' cancel rename entry cleanly '''
        root.bind( '<Return>' )
        root.bind( '<Escape>' )
        e.destroy()
        lab.grid(row=li,column=1)        
        self.lock=False
    
    def rename(self, li, ev=None):
        ''' replace filename label with entry '''
        if self.lock:
            return
        self.lock=True
        lab=self.fileLabels[li]
        oldName=lab["text"]
        newName=StringVar()
        e=Entry(self.listfileFrame, textvariable= newName, font=fnt)
        root.bind('<Return>', functools.partial( self.renameFinish, lab, e, newName, li ) )
        root.bind('<Escape>', functools.partial( self.renameCancel, lab, e, newName, li ) )
        e.grid(row=li,column=1)
        lab.grid_forget()
  
    def _getMarked( self ):
        ''' returns all selected files and directories '''
        return [lbl["text"] for btn, lbl in zip(self.fileCheckbtnsVar, self.fileLabels ) if btn.get()==1 ]
    
    def delSelected(self):
        ''' sends request to server to delete all selected files and 
        directories'''
        if self.lock:
            return
        marked= self._getMarked()
        print marked
        for fname in marked:
            # check if f in self.files
            clientsocket.send(json.dumps({"cmd":"delete","type":self.files[fname]["type"],"path":self.curDir+fname}))
            resp= clientsocket.recv(1024)
            print resp
            if not "ok" in resp:
                errorDialog(resp)
        self.updateDirFiles()
            
    def downloadSelected(self):
        ''' download selected files into directory specified by user '''
        if self.lock:
            return
        marked= self._getMarked()
        print marked
        path= tkFileDialog.asksaveasfilename( )
        if os.path.exists( path ):
            if os.path.isfile( path ):
                errorDialog( "You should specify directory to store files" )
                return
            if not os.path.isdir( path ):
                errorDialog( "You should specify directory to store files" )
                return
        else:
            os.mkdir(path)
        for fname in marked:
            # check if f in self.files
            if "|" in fname:
                clientsocket.send(json.dumps({"cmd":"download","type":self.files[fname]["type"],"path":fname}))
            else:
                clientsocket.send(json.dumps({"cmd":"download","type":self.files[fname]["type"],"path":self.curDir+fname}))
            resp= json.loads(clientsocket.recv(1024))
            print "got",  resp
            while resp:
                try:
                    if resp["path"] == self.curDir:
                        dpath= resp["path"]
                    else:
                        dpath= resp["path"][len(self.curDir):]
                    sysPath=DropboxToSystemPath( dpath, path )
                    print fname
                    print path
                    print dpath
                    print sysPath
                    if resp["type"]=="file":
                        clientsocket.send("ok")
                        dirname= os.path.dirname(os.path.abspath( sysPath ))
                        print "saving file",sysPath, dirname
                        try:
                            os.makedirs(dirname)
                        except :
                            pass
                        size= resp['size']
                        with open(sysPath,"wb") as fd:
                            s= 0
                            print "file opened, ", s, size, type(size), s<size
                            while s < size:
                                e= min(s+1024, size)
                                chSize= e-s
                                chunk= clientsocket.recv(chSize)
                                fd.write(chunk)
                                #print s, e, size
                                s= e
                        print "done"
                    elif resp["type"]=="dir":
                        os.mkdir(sysPath)
                    clientsocket.send("ready")
                except Exception as err:
                    resp=None
                    errorDialog(err)
                resp= json.loads(clientsocket.recv(1024))

    def createGroup(self):
        pass

class CreateToolTip(object):
    """
    create a tooltip for a given widget
    """
    def __init__(self, widget, text='widget info'):
        self.waittime = 300     #miliseconds
        self.wraplength = 180   #pixels
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.leave)
        self.widget.bind("<ButtonPress>", self.leave)
        self.id = None
        self.tw = None

    def enter(self, event=None):
        self.schedule()

    def leave(self, event=None):
        self.unschedule()
        self.hidetip()

    def schedule(self):
        self.unschedule()
        self.id = self.widget.after(self.waittime, self.showtip)

    def unschedule(self):
        id = self.id
        self.id = None
        if id:
            self.widget.after_cancel(id)

    def showtip(self, event=None):
        x = y = 0
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        # creates a toplevel window
        self.tw = Toplevel(self.widget)
        # Leaves only the label and removes the app window
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        label = Label(self.tw, text=self.text, justify='left',
                       background="#ffffff", relief='solid', borderwidth=1,
                       wraplength = self.wraplength)
        label.pack(ipadx=1)

    def hidetip(self):
        tw = self.tw
        self.tw= None
        if tw:
            tw.destroy()
class UserPermissionFrame(object):
    def __init__(self, pf, **kwargs ):
        ''' defining GUI elements.  '''
        self.pf= pf
        self.mainFrame=Frame( pf.permissionFrame )
        self.mainFrame.pack( side="left", expand=1 )
        title= kwargs.pop( 'title', "Users" )
        self.addItemPrompt= kwargs.pop( 'addUserPrompt', "username: " )
        self.listCmd= kwargs.pop( 'listCmd', "getPathUserPermissions" )
        self.addCmd= kwargs.pop( 'addCmd', "addPathUserPermissions" )
        self.delCmd= kwargs.pop( 'delCmd', "delPathUserPermissions" )
        self.addImgFileName= kwargs.pop( 'addImgFileName', "icons8-add-user-50.gif" )
        self.addUserPermissionTolltip= kwargs.pop( 'addUserPermissionTolltip', "Add User" )
        Label(self.mainFrame, text=title,font=fnt).pack()
        self.groupCheckbtns=[]
        self.groupNameLabels=[]
        self.addDialogStarted= False
        self.changeDialogStarted= False
        self.permissionsTypes= None
        if True: 
          self.toolbar= Frame( self.mainFrame )
          self.bottombar= Frame( self.mainFrame )
        

          self.listFrameTop=Frame(self.mainFrame, background= "#F8F8F8")
          self.canvas=Canvas(self.listFrameTop)
          self.listFrame=Frame(self.canvas, background= "#F8F8F8")
          scrollbar=Scrollbar(self.listFrameTop,orient="vertical",command=self.canvas.yview)
          self.canvas.config( yscrollcommand=scrollbar.set)
          scrollbar.pack(side="right",fill="y")
          self.canvas.pack(side="left", fill=BOTH, expand=1)
          self.canvas.create_window((0,0),window=self.listFrame,anchor='nw')
          self.listFrame.bind("<Configure>",lambda _: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

          self.listFrameTop.pack(fill=BOTH)
          self.toolbar.pack()
          self.bottombar.pack()
           
          addUsrImg=PhotoImage(file= self.addImgFileName)
          addUserBt=Button( self.toolbar, image=addUsrImg,command=self.addDialog )
          addUserBt.image= addUsrImg
          addUserBt.pack(side="left")
          ttp_addUserBt=CreateToolTip(addUserBt,self.addUserPermissionTolltip)

          self.delUsrImg=PhotoImage(file= "icons8-empty-trash-50.gif")
          self.delBt=Button( self.toolbar, image=self.delUsrImg,command=self.deleteUsers )
          self.delBt.image= self.delUsrImg
          self.delBt.pack(side="left")
          selBt_ttp = CreateToolTip(self.delBt, 'Delete')
          
    def addDialog(self):
        if self.addDialogStarted:
            return
        self.addDialogStarted= True
        self.grNameVar=StringVar()
        dialog= Toplevel()
        dialog.title( 'add permissions' )
        Label( dialog, text= self.pf.mf.curDirVar.get(),font=fnt ).grid(row=1, column= 1, columnspan=2)

        Label( dialog, text= self.addItemPrompt,font=fnt ).grid(row=2, column= 1)
        Entry(dialog,text = self.grNameVar, font=fnt ).grid(row=2, column= 2)
        Label( dialog, text= "permissions",font=fnt ).grid(row=3, column= 1)
        listbox= Listbox(dialog, selectmode=EXTENDED, exportselection=0)        
        for p in self.permissionsTypes:
            listbox.insert(END, p)
        listbox.grid(row=3, column= 2)  
        self.permissionSelectionListbox= listbox
        #TODO: add listbox for permission 
        Button(dialog, text = "Submit",font=fnt,
           command= functools.partial( self.serverRequestAdd, dialog )   ).grid(row=4, column= 1)  
        Button(dialog, text = "Cancel",font=fnt,
           command= functools.partial( self.serverRequestCancel, dialog )   ).grid(row=4, column= 2) 
        dialog.protocol("WM_DELETE_WINDOW", functools.partial( self.serverRequestCancel, dialog ) )
    def serverRequestAdd(self,dialog):
        listbox= self.permissionSelectionListbox
        perms = [listbox.get(i) for i in listbox.curselection()]
        dialog.destroy()
        clientsocket.send(json.dumps({"cmd":self.addCmd,
            "path":self.pf.mf.curDirVar.get(),
            "user": self.grNameVar.get(),
            "permissions": perms }))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
        self.showList( self.fname )
        self.addDialogStarted= False        
    def serverRequestCancel(self,dialog):
        dialog.destroy()
        self.addDialogStarted= False  
    def _getMarked( self ):
        return [lbl["text"] for btn, lbl in zip(self.groupCheckbtnsVar, self.groupNameLabels ) if btn.get()==1 ]    
    def deleteUsers(self):
        marked=self._getMarked()
        print "delete ", marked
        for user in marked:
            clientsocket.send(json.dumps({"cmd":self.delCmd,
               "user":user,
               "path":self.fname,
               "permissions": '*' }))
            reply=clientsocket.recv(1024)
            if "error" in reply:
                errorDialog(reply)
        self.showList( self.fname )
    def showList( self, fname, ev=None ):
        #self.titleLabel['text']= fname
        self.fname= fname
        if not self.permissionsTypes:
            clientsocket.send(json.dumps( {"cmd": "getPermissionList" } ))
            try:
                msg= clientsocket.recv(1024)
                print msg
                self.permissionsTypes= json.loads(msg)
            except Exception as err:
                print err
                errorDialog("there is a pproblem with server connection"+ str(msg) )
                return 
        clientsocket.send(json.dumps( {"cmd":self.listCmd, "path":fname } ))
        msg= clientsocket.recv(1024)
        
        print "got ", msg
        if "error" in msg:
            errorDialog(msg)
            return
        sdata = json.loads(msg)
        print "got from server: ", sdata
        for bt in self.groupCheckbtns:
            bt.destroy()
        self.groupCheckbtns=[]
        self.groupCheckbtnsVar= []
        for l in self.groupNameLabels:
            l.destroy()
        self.groupNameLabels= []
        
        data= {'users':{}}
        for r in sdata:
            if not r[0] in data['users']:
                data['users'][r[0]]= []
            data['users'][r[0]].append(r[1])
        
        self.permissiondata= data
        
        if 'users' in data:
            for gi, grName in enumerate(data['users']):
                var= IntVar()
                chBt=Checkbutton ( self.listFrame, variable=var )
                chBt.grid(column=0,row=gi)
                print 'creating label', grName
                l=Label( self.listFrame, text=grName, font=fnt)
                l.grid(column=1,row=gi)
                
                l.bind( "<Button-1>", functools.partial( self.changePermissionsDialog, grName ))
                        
                self.groupNameLabels.append(l)
                self.groupCheckbtns.append(chBt)
                self.groupCheckbtnsVar.append(var)

        
        self.show()
    def changePermissionsDialog(self, name, ev= None):
        print "changePermissionsDialog"
        if self.changeDialogStarted:
            return
        self.changeDialogStarted= True
        self.grNameVar=StringVar()
        dialog= Toplevel()
        dialog.title( 'change permissions' )
        Label( dialog, text= self.fname,font=fnt ).grid(row=1, column= 1, columnspan=2)

        Label( dialog, text= self.addItemPrompt,font=fnt ).grid(row=2, column= 1)
        Label(dialog,text = name, font=fnt ).grid(row=2, column= 2)
        Label( dialog, text= "permissions",font=fnt ).grid(row=3, column= 1)
        listbox= Listbox(dialog, selectmode=EXTENDED, exportselection=0)        
        for pi, p in enumerate(self.permissionsTypes):
            listbox.insert(END, p)
            if p in self.permissiondata['users'][name]:
                listbox.select_set(pi)
        listbox.grid(row=3, column= 2)  
        #self.permissionSelectionListbox= listbox
        Button(dialog, text = "Submit",font=fnt,
           command= functools.partial( self.serverRequestChange, dialog, listbox, name )   ).grid(row=4, column= 1)  
        Button(dialog, text = "Cancel",font=fnt,
           command= functools.partial( self.serverRequestChangeCancel, dialog )   ).grid(row=4, column= 2)  
    def serverRequestChange(self, dialog, listbox, name):
        new_perm = [listbox.get(i) for i in listbox.curselection()]
        orig_perm= self.permissiondata['users'][name]
        permsToAdd= [p for p in new_perm if p not in orig_perm]
        permsToRemove= [p for p in orig_perm if p not in new_perm]
        dialog.destroy()
        clientsocket.send(json.dumps({"cmd":self.addCmd,
            "path":self.pf.mf.curDirVar.get(),
            "user": name,
            "permissions": permsToAdd }))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
            return
        clientsocket.send(json.dumps({"cmd":self.delCmd,
            "path":self.pf.mf.curDirVar.get(),
            "user": name,
            "permissions": permsToRemove }))
        reply=clientsocket.recv(1024)
        if "error" in reply:
            errorDialog(reply)
            return
        self.showList( self.fname )
        self.changeDialogStarted= False
    def serverRequestChangeCancel(self, dialog):
        self.changeDialogStarted= False
        dialog.destroy()
    def show(self):
        self.mainFrame.pack(fill=BOTH)
    
class GroupPemissionFrame(UserPermissionFrame):
    ''' has the same functionality like UserPermissionFrame, therefor 
    is just a derived class'''
    def __init__( self, pf, **kwargs ):
        super(GroupPemissionFrame,self).__init__(pf, 
            title= "Groups", 
            addUserPrompt="group name: ",
            listCmd="getPathGroupPermissions", 
            addCmd= "addPathGroupPermissions",
            delCmd= "delPathGroupPermissions",
            addUserPermissionTolltip="Add Group",
            addImgFileName="icons8-add-group-50.gif")
        
class PermissionFrame():
    ''' defines GUI element and processes events for PermissionFrame
    activity (related to activity of managing permissions)'''
    def __init__(self, mf ):
        
        self.mf= mf
        self.permissionFrame= Frame( mf.mainFrame )
        self.uFrame= UserPermissionFrame(self)
        self.gFrame= GroupPemissionFrame(self)
        
        self.perCheckbtns=[]
        self.selectAllVar=IntVar()
        self.perUserLabels= []
        self.perGroupLabels= []
        self.addGroupDialogStarted= False
        
    def show(self):
        self.permissionFrame.pack(fill=BOTH)
    def hide(self):
        self.permissionFrame.pack_forget()
    def initPermissionFrame(self, fname):
        self.fname= fname
        self.uFrame.showList( fname )
        self.gFrame.showList( fname )
# parameters     
HOST = '127.0.0.1' # localhost  
PORT = 50002 #read_free_port()
BUFSIZ = 1024
ADDR = (HOST,PORT)
clientsocket = socket(AF_INET,SOCK_STREAM)
lgn=Login(clientsocket)

root = Tk()
root.minsize(600, 450) 

loginFrame=Frame(root)
loginFrame.pack(fill="y")
root.title("Dropbox")

def loginRegisterButtonClicked():
    registerFrame.pack(fill="y")
    loginFrame.pack_forget()
def registerBackButtonClicked():
    registerFrame.pack_forget()
    loginFrame.pack(fill="y")
   

# on double click send current selection to the server
fnt= tkFont.Font(family="David", size=20, weight=tkFont.BOLD, slant=tkFont.ITALIC)
if True :# login window
    username = StringVar() # entry text

    Label(loginFrame, text="DROPBOX LOGIN", font=fnt).pack()
    Label(loginFrame, text="").pack()
    usernameLable = Label(loginFrame, text="Username * ", font=fnt)
    usernameLable.pack()
    usernameEntry = Entry(loginFrame,text = username, font=fnt)
    usernameEntry.pack(expand="NO", fill="both" )
    password = StringVar() # entry text
    passwordLable = Label(loginFrame, text="Password *: ", font=fnt)
    passwordLable.pack()
    passwordEntry = Entry(loginFrame, text = password, font=fnt, show="*")
    passwordEntry.pack(expand="NO", fill="both" )
    btLogin = Button(loginFrame, text = "Login",font=fnt,command=lgn.login) 
    btLogin.pack(side= "left")  
    Label(loginFrame, text=" or ", font=fnt).pack(side= "left")
    btRegister = Button(loginFrame, text = "Register",font=fnt,command=loginRegisterButtonClicked) 
    btRegister.pack()  


if True: #register window
    password2 = StringVar()
    registerFrame=Frame(root)
    Label(registerFrame, text="DROPBOX REGISTER", font=fnt).pack()
    Label(registerFrame, text="").pack()
    usernameLable = Label(registerFrame, text="Username * ", font=fnt)
    usernameLable.pack()
    usernameEntry = Entry(registerFrame,text = username, font=fnt)
    usernameEntry.pack(expand="NO", fill="both" )
    #password = StringVar() # entry text
    passwordLable = Label(registerFrame, text="Password *: ", font=fnt)
    passwordLable.pack()
    passwordEntry = Entry(registerFrame,text = password, font=fnt, show="*")
    passwordEntry.pack(expand="NO", fill="both" )
    passwordRepeatLable = Label(registerFrame, text="Password Repeat*: ", font=fnt)
    passwordRepeatLable.pack()
    passwordRepeatEntry = Entry(registerFrame,text = password2, font=fnt, show="*")
    passwordRepeatEntry.pack(expand="NO", fill="both")
    btLogin = Button(registerFrame, text = "Back",font=fnt,command=registerBackButtonClicked) 
    btLogin.pack(side= "left") 
    Label(registerFrame, text=" or ", font=fnt).pack(side= "left")
    btRegister = Button(registerFrame, text = "Register",font=fnt,command=lgn.register) 
    btRegister.pack()      


    
if True: # home page
    mainFrame=Frame(root, background="#D0D0D8")
    mf=MainFrame(mainFrame)
    gf= GroupFrame(mf)
fnt= tkFont.Font(family="David", size=20, weight=tkFont.BOLD, slant=tkFont.ITALIC)
    
root.resizable(False, False)
try:
  clientsocket.connect(ADDR)
  data = clientsocket.recv(BUFSIZ)
  # on close window button press, we need to notify the server
  # that the session is ended. 
  root.protocol("WM_DELETE_WINDOW", on_closing)
  root.mainloop()
  clientsocket.close()
  #listbox.insert(END,"session ended succesfully")
  root.destroy()
except IOError as e:
        print "Couldn't establish connection"
        root.destroy()

